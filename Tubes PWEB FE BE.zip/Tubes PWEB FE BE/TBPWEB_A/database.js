const mysql = require('mysql');

// Membuat koneksi ke database
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "tb_pweb_a"
});

// Menjalankan koneksi
connection.connect((error) => {
  if (error) {
    console.error('Terjadi kesalahan saat koneksi ke database:', error);
    return;
  }

  console.log('Koneksi ke database berhasil!');
});

module.exports = connection;
