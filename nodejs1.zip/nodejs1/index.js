const express = require('express')
const app = express()
const port = 3000
const response = require('./response')
const bodyParser = require("body-parser")
const db = require ('./connection')
const moment = require('moment')

app.get('/', (req, res) => {
  response(200, "API ready to GO", "success", res)
})

app.get('/users', (req, res) => {
  const sql = "SELECT * FROM users"
  db.query(sql,(err,fields) => {
    if (err) throw err
    response(200, fields, "success", res)
  })
})

app.get('/users/:user_id', (req, res) => {
  const user_id = req.params.user_id
  const sql = `SELECT * FROM users WHERE user_id = ${user_id}`
  db.query(sql, (err,fields) =>{
    if (err) throw err
    response(200, fields, "get detail username", res)
  })
  
})

// app.post ("/users", (req,res) => {
//   const { username, 
//     email, 
//     password, 
//     active, 
//     avatar, 
//     createdAt, 
//     updateAt } = req.body

//   console.log (req.body)
//   const sql = `INSERT INTO users ( username, email, password, active, avatar, created_at, update_at ) 
//   VALUES ('${username}', '${email}', '${password}', ${active}, '${avatar}', '${createdAt}', '${updateAt}' )`

//   db.query(err,fields => {
//     console.log(fields)
//   })
//   res.send(200,"ashiaap")
//   // response(200, "ini posting", "insert data added success", res)
app.post('/users', function (req, res) {
  const username = req.body.username;
  const email = req.body.email;
  const password = req.body.password;
  const active = req.body.active;
  const avatar = req.body.avatar;
  const created_at = req.body.created_at;
  const update_at = req.body.update_at;

  const sql = "INSERT INTO users (username, email, password, active, avatar, created_at, update_at) VALUES (?, ?, ?, ?, ?, ?, ?)";
  const values = [username, email, password, active, avatar, created_at, update_at];

  connection.query(sql, values, function (err, result) {
      if (err) {
          res.send(500, 'Error inserting user');
      } else {
          res.send(200, 'User inserted successfully');
      }
  });
});
// })

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})