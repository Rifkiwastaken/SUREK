const express = require('express')
const app = express()
const mysql = require('mysql');
const connection = require('./database');
const port = 3000

app.get('/', (req, res) => {
  res.send('Hello World!adaw')
})

// Menambahkan middleware body-parser
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

//mengupdate users
app.put('/users/:id', (req, res) => {
    const { id } = req.params;
    const { username, email, password, active, avatar } = req.body;
    const updated_at = new Date();
  
    const query = 'UPDATE users SET username=?, email=?, password=?, active=?, avatar=?, updated_at=? WHERE user_id=?';
    connection.query(query, [username, email, password, active, avatar, updated_at, id], (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).send(err);
      }
      console.log(`User with ID ${id} has been updated.`);
      res.send(result);
    });
  });
//menampilakn seluruh users
app.get('/users', (req, res) => {
    connection.query('SELECT * FROM users', (err, rows) => {
      if (err) throw err;
  
      res.json(rows);
    });
  });

// Menambahkan users
app.post('/users', (req, res) => {
    const { username, email, password, active, avatar } = req.body;
    const createdAt = new Date();
    const updatedAt = new Date();
  
    connection.query(
      'INSERT INTO users (username, email, password, active, avatar, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [username, email, password, active, avatar, createdAt, updatedAt],
      (error, results) => {
        if (error) {
          console.error('Error creating user: ', error);
          res.status(500).send('Error creating user.');
          return;
        }
        res.status(201).json({ message: 'User created successfully.', userId: results.insertId });
      }
    );
  });

//delete users
app.delete('/users/:id', (req, res) => {
    const id = req.params.id;
    db.query(`DELETE FROM users WHERE user_id = ${id}`, (err, result) => {
      if (err) {
        console.log(err);
        res.status(500).send('Error deleting user');
      }
      res.send('User deleted successfully');
    });
  });

//add form
app.post('/forms', (req, res) => {
    // Mendapatkan data dari request
    const user_id = req.body.user_id;
    const title = req.body.title;
    const description = req.body.description;

    // Membuat query untuk insert data ke tabel forms
    const query = `INSERT INTO forms (user_id, title, description, created_at, updated_at) VALUES (${user_id}, '${title}', '${description}', NOW(), NOW())`;

    // Menjalankan query
    connection.query(query, (err, result) => {
        if (err) {
            console.log('Gagal menambahkan data: ' + err);
            res.sendStatus(500);
            return;
        }
        console.log('Data berhasil ditambahkan');
        
        // Mendapatkan nilai form_id dari hasil query
        const form_id = result.insertId;
        
        // Mengembalikan nilai form_id sebagai response
        res.status(201).json({
            form_id,
            user_id,
            title,
            description
        });
    });
});

//update forms
app.put('/forms/:form_id', (req, res) => {
    const form_id = req.params.form_id;
    const { user_id, title, description } = req.body;
  
    // Membuat query untuk mengupdate data pada tabel forms
    const query = `UPDATE forms SET user_id = ${user_id}, title = '${title}', description = '${description}', updated_at = NOW() WHERE form_id = ${form_id}`;
  
    // Menjalankan query
    connection.query(query, (err, result) => {
      if (err) {
        console.error('Gagal mengupdate data: ' + err);
        res.sendStatus(500);
        return;
      }
  
      console.log(`Berhasil mengupdate data pada form_id ${form_id}`);
      res.sendStatus(204);
    });
  });


//read form
app.get('/forms', (req, res) => {
    // Membuat query untuk membaca data dari tabel forms
    const query = `SELECT * FROM forms`;
  
    // Menjalankan query
    connection.query(query, (err, result) => {
      if (err) {
        console.error('Gagal membaca data: ' + err);
        res.sendStatus(500);
        return;
      }
  
      console.log('Berhasil membaca data dari tabel forms');
      res.json(result);
    });
  });

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})